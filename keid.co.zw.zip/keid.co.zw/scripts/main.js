/* Main entry point */
document.addEventListener('DOMContentLoaded', () => {
  // Navigation event listeners
  homeLink.addEventListener('click', () => renderView('home'));
  productsLink.addEventListener('click', () => renderView('products'));
  servicesLink.addEventListener('click', () => renderView('services'));
  aboutLink.addEventListener('click', () => renderView('about'));
  contactLink.addEventListener('click', () => renderView('contact'));
  navProfileLink.addEventListener('click', () =>
    renderView('profile', currentUser ? currentUser.id : null)
  );
  navDashboardLink.addEventListener('click', () => renderView('dashboard'));
  navFavoritesLink.addEventListener('click', () => renderView('favorites'));
  navSettingsLink.addEventListener('click', () => renderView('settings'));

  // Image upload event listener
  if (imageUpload) {
    imageUpload.addEventListener('click', () => imageInput.click());
  }
  if (imageInput) {
    imageInput.addEventListener('change', (e) => {
      const files = e.target.files;
      if (files.length > 5) {
        showMessage('You can upload a maximum of 5 images', 'error');
        return;
      }
      uploadedImages = [];
      imagePreview.innerHTML = '';
      Array.from(files).forEach((file) => {
        if (file.type.startsWith('image/')) {
          const reader = new FileReader();
          reader.onload = (e) => {
            uploadedImages.push(e.target.result);
            renderImagePreviews();
          };
          reader.readAsDataURL(file);
        }
      });
    });
  }

  if (closeFullImageBtn) {
    closeFullImageBtn.addEventListener('click', () => {
      fullImageView.style.display = 'none';
    });
  }

  // Initial view render
  renderView('home');
});
