/* Modal-related view functions */

function openEditProfileModal(user) {
  if (!editProfileModal) return;
  document.getElementById('edit-profile-display-name').value = user.displayName;
  document.getElementById('edit-profile-location').value = user.location;
  document.getElementById('edit-profile-phone').value = user.phone;
  document.getElementById('edit-profile-whatsapp').value = user.whatsapp;
  document.getElementById('edit-profile-bio').value = user.bio;
  editProfilePicPreview.innerHTML = `
    <div class="image-preview-item">
      <img src="${user.profilePic}" alt="Profile Picture" style="width:80px;height:80px;object-fit:cover;border-radius:4px;">
    </div>
  `;
  document.getElementById('edit-profile-pic-upload')?.addEventListener('click', () => {
    editProfilePicInput.click();
  });
  editProfilePicInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        editProfilePicPreview.innerHTML = `
          <div class="image-preview-item">
            <img src="${e.target.result}" alt="Profile Picture" style="width:80px;height:80px;object-fit:cover;border-radius:4px;">
          </div>
        `;
      };
      reader.readAsDataURL(file);
    }
  });
  editProfileForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const displayName = document.getElementById('edit-profile-display-name').value;
    const location = document.getElementById('edit-profile-location').value;
    const phone = document.getElementById('edit-profile-phone').value;
    const whatsapp = document.getElementById('edit-profile-whatsapp').value;
    const bio = document.getElementById('edit-profile-bio').value;
    const profilePic = editProfilePicPreview.querySelector('img').src;
    currentUser.displayName = displayName;
    currentUser.location = location;
    currentUser.phone = phone;
    currentUser.whatsapp = whatsapp;
    currentUser.bio = bio;
    currentUser.profilePic = profilePic;
    showMessage('Profile updated successfully!', 'success');
    closeModal(editProfileModal);
    updateAuthUI();
    renderProfile(currentUser.id);
  });
  openModal(editProfileModal);
}

function openEditListingModal(listingId) {
  if (!editListingModal) return;
  const listing = [...fakeDb.products, ...fakeDb.services].find((item) => item.id === Number(listingId));
  if (!listing) {
    showMessage('Listing not found', 'error');
    return;
  }
  document.getElementById('edit-listing-type').value = listing.type;
  document.getElementById('edit-listing-title').value = listing.title;
  document.getElementById('edit-listing-price').value = listing.price;
  document.getElementById('edit-listing-location').value = listing.location;
  document.getElementById('edit-listing-description').value = listing.description;
  renderEditListingImagePreviews(listing);
  editImageUpload.addEventListener('click', () => {
    editImageInput.click();
  });
  editImageInput.addEventListener('change', (e) => {
    const files = e.target.files;
    if (files.length > 5) {
      showMessage('You can upload a maximum of 5 images', 'error');
      return;
    }
    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          listing.images.push(e.target.result);
          renderEditListingImagePreviews(listing);
        };
        reader.readAsDataURL(file);
      }
    });
  });
  editListingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    listing.type = document.getElementById('edit-listing-type').value;
    listing.title = document.getElementById('edit-listing-title').value;
    listing.price = parseFloat(document.getElementById('edit-listing-price').value);
    listing.location = document.getElementById('edit-listing-location').value;
    listing.description = document.getElementById('edit-listing-description').value;
    showMessage('Listing updated successfully!', 'success');
    closeModal(editListingModal);
    renderDashboard();
  });
  openModal(editListingModal);
}

function openContactModal(userId) {
  const user = fakeDb.users.find((u) => u.id === Number(userId));
  if (!user) {
    showMessage('User not found', 'error');
    return;
  }
  document.getElementById('contact-name').textContent = user.name;
  document.getElementById('whatsapp-btn').onclick = () => {
    window.open(`https://wa.me/${user.whatsapp}`, '_blank');
  };
  document.getElementById('call-btn').onclick = () => {
    window.location.href = `tel:${user.phone}`;
  };
  openModal(contactModal);
}
