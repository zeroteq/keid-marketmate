/* Dashboard view functions */

function renderDashboard() {
  if (!currentUser) {
    mainContent.innerHTML = '<p>Please login to access the dashboard</p>';
    return;
  }
  const userProducts = fakeDb.products.filter((product) => product.userId === currentUser.id);
  const userServices = fakeDb.services.filter((service) => service.userId === currentUser.id);
  const html = `
    <div class="dashboard-container">
      <div class="dashboard-sidebar">
        <ul class="dashboard-nav">
          <li><a href="#" class="active" id="dashboard-tab"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
          <li><a href="#" id="listings-tab"><i class="fas fa-list"></i> Listings</a></li>
          <li><a href="#" id="favorites-tab"><i class="fas fa-heart"></i> Favorites</a></li>
          <li><a href="#" id="settings-tab"><i class="fas fa-cog"></i> Settings</a></li>
        </ul>
      </div>
      <div class="dashboard-content">
        <div class="dashboard-header">
          <h2 class="dashboard-title">Dashboard</h2>
          <button class="btn-success" id="add-listing-btn">Add Listing</button>
        </div>
        <div class="dashboard-stats">
          <div class="stat-card">
            <div class="stat-value">${userProducts.length + userServices.length}</div>
            <div class="stat-label">Total Listings</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${currentUser.likes}</div>
            <div class="stat-label">Total Likes</div>
          </div>
        </div>
        <h3 class="section-title">Your Listings</h3>
        <div class="listings-grid">
          ${userProducts.map((product) => createListingCard(product, true)).join('')}
          ${userServices.map((service) => createListingCard(service, true)).join('')}
        </div>
      </div>
    </div>
  `;
  mainContent.innerHTML = html;

  document.getElementById('dashboard-tab').addEventListener('click', () => renderDashboard());
  document.getElementById('listings-tab').addEventListener('click', () => renderView('listings'));
  document.getElementById('favorites-tab').addEventListener('click', () => renderView('favorites'));
  document.getElementById('settings-tab').addEventListener('click', () => renderView('settings'));
  document.getElementById('add-listing-btn').addEventListener('click', () => openModal(addListingModal));

  addListingCardEventListeners();

  document.querySelectorAll('#edit-listing-btn').forEach((button) => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = button.getAttribute('data-id');
      openEditListingModal(id);
    });
  });

  document.querySelectorAll('#delete-listing-btn').forEach((button) => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = button.getAttribute('data-id');
      handleDeleteListing(id);
    });
  });
}

function handleDeleteListing(listingId) {
  if (!currentUser) {
    showMessage('Please login to delete a listing', 'error');
    return;
  }
  listingId = Number(listingId);
  const productIndex = fakeDb.products.findIndex((product) => product.id === listingId);
  const serviceIndex = fakeDb.services.findIndex((service) => service.id === listingId);
  if (productIndex !== -1) {
    fakeDb.products.splice(productIndex, 1);
  } else if (serviceIndex !== -1) {
    fakeDb.services.splice(serviceIndex, 1);
  } else {
    showMessage('Listing not found', 'error');
    return;
  }
  showMessage('Listing deleted successfully', 'success');
  renderDashboard();
}
