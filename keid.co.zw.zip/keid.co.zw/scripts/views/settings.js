/* Settings view functions */

function renderSettings() {
  if (!currentUser) {
    mainContent.innerHTML = '<p>Please login to access settings</p>';
    return;
  }
  const html = `
    <div class="form-container">
      <h2 class="form-title">Settings</h2>
      <form id="settings-form">
        <div class="form-group">
          <label for="settings-name">Full Name</label>
          <input type="text" id="settings-name" value="${currentUser.name}" required>
        </div>
        <div class="form-group">
          <label for="settings-email">Email</label>
          <input type="email" id="settings-email" value="${currentUser.email}" required>
        </div>
        <div class="form-group">
          <label for="settings-password">Password</label>
          <input type="password" id="settings-password" placeholder="Enter new password">
        </div>
        <div class="form-group">
          <label for="settings-confirm-password">Confirm Password</label>
          <input type="password" id="settings-confirm-password" placeholder="Confirm new password">
        </div>
        <button type="submit" class="btn-primary">Save Changes</button>
      </form>
    </div>
  `;
  mainContent.innerHTML = html;
  document.getElementById('settings-form').addEventListener('submit', handleSettingsUpdate);
}

function handleSettingsUpdate(e) {
  e.preventDefault();
  const name = document.getElementById('settings-name').value;
  const email = document.getElementById('settings-email').value;
  const password = document.getElementById('settings-password').value;
  const confirmPassword = document.getElementById('settings-confirm-password').value;
  if (password && password !== confirmPassword) {
    showMessage('Passwords do not match', 'error');
    return;
  }
  currentUser.name = name;
  currentUser.email = email;
  if (password) currentUser.password = password;
  showMessage('Settings updated successfully!', 'success');
}
