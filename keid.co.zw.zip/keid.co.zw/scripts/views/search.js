/* Search view functions */

function renderSearchResults(results, query, locationFilter) {
  const sortedResults = sortListings(results, currentSortBy);
  const html = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
      <div>
        <h2 class="section-title">Search Results</h2>
        <p class="section-subtitle">Showing results for "${query}" ${
    locationFilter ? 'in ' + locationFilter : ''
  }</p>
      </div>
      <div>
        <select id="sort-by" style="padding:8px; border-radius:4px;">
          <option value="latest" ${currentSortBy === 'latest' ? 'selected' : ''}>Sort by: Latest</option>
          <option value="name" ${currentSortBy === 'name' ? 'selected' : ''}>Sort by: Name</option>
          <option value="price-low-to-high" ${currentSortBy === 'price-low-to-high' ? 'selected' : ''}>Sort by: Price (Low to High)</option>
          <option value="price-high-to-low" ${currentSortBy === 'price-high-to-low' ? 'selected' : ''}>Sort by: Price (High to Low)</option>
        </select>
      </div>
    </div>
    <div class="listings-grid">
      ${sortedResults.map((item) => createListingCard(item)).join('')}
    </div>
  `;
  mainContent.innerHTML = html;
  document.getElementById('sort-by').addEventListener('change', (e) => {
    currentSortBy = e.target.value;
    const sorted = sortListings(results, currentSortBy);
    renderSearchResults(sorted, query, locationFilter);
  });
  addListingCardEventListeners();
}

function handleSearch() {
  const query = searchInput.value.trim().toLowerCase();
  const loc = locationSelect.value;
  const searchType = searchInput.getAttribute('data-search-type'); // 'products', 'services' or 'all'
  let results = [];
  if (searchType === 'products') {
    results = fakeDb.products.filter(
      (product) =>
        (product.title.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query)) &&
        (loc ? product.location === loc : true)
    );
  } else if (searchType === 'services') {
    results = fakeDb.services.filter(
      (service) =>
        (service.title.toLowerCase().includes(query) ||
          service.description.toLowerCase().includes(query)) &&
        (loc ? service.location === loc : true)
    );
  } else {
    const filteredProducts = fakeDb.products.filter(
      (product) =>
        (product.title.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query)) &&
        (loc ? product.location === loc : true)
    );
    const filteredServices = fakeDb.services.filter(
      (service) =>
        (service.title.toLowerCase().includes(query) ||
          service.description.toLowerCase().includes(query)) &&
        (loc ? service.location === loc : true)
    );
    results = [...filteredProducts, ...filteredServices];
  }
  renderSearchResults(results, query, loc);
}
