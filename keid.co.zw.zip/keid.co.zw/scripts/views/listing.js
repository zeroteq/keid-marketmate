/* Listing view functions */

function createListingCard(listing, isDashboard = false) {
  const isLiked = fakeDb.userLikes.some(
    (like) => currentUser && like.userId === currentUser.id && like.listingId === listing.id
  );
  const isFavorited = fakeDb.favorites.some(
    (fav) => currentUser && fav.userId === currentUser.id && fav.listingId === listing.id
  );
  const lister = fakeDb.users.find((user) => user.id === listing.userId);
  return `
    <div class="listing-card" data-id="${listing.id}">
      <div class="listing-image" style="background-image: url('${listing.images[0]}')">
        <div class="listing-type ${listing.type === 'product' ? 'type-product' : 'type-service'}">
          ${listing.type}
        </div>
      </div>
      <div class="listing-content">
        <h3 class="listing-title">${listing.title}</h3>
        <p class="listing-price">$${listing.price}</p>
        <p class="listing-location"><i class="fas fa-map-marker-alt"></i> ${listing.location}</p>
        <p class="listing-lister"><i class="fas fa-user"></i> Listed by: ${
          lister ? lister.displayName : 'Unknown'
        }</p>
        <div class="listing-actions">
          <button class="listing-like ${isLiked ? 'active' : ''}" data-id="${listing.id}">
            <i class="fas fa-thumbs-up"></i> ${listing.likes}
          </button>
          <button class="listing-favorite ${isFavorited ? 'active' : ''}" data-id="${listing.id}">
            <i class="fas fa-heart"></i>
          </button>
          ${
            isDashboard
              ? `
            <button class="btn-info btn-sm" id="edit-listing-btn" data-id="${listing.id}">Edit</button>
            <button class="btn-danger btn-sm" id="delete-listing-btn" data-id="${listing.id}">Delete</button>
          `
              : ''
          }
        </div>
      </div>
    </div>
  `;
}

function renderListingDetail(id) {
  id = Number(id);
  const listing = [...fakeDb.products, ...fakeDb.services].find((item) => item.id === id);
  if (!listing) {
    mainContent.innerHTML = '<p>Listing not found</p>';
    return;
  }
  const owner = fakeDb.users.find((user) => user.id === listing.userId);
  const isLiked = fakeDb.userLikes.some(
    (like) => currentUser && like.userId === currentUser.id && like.listingId === listing.id
  );
  const isFavorited = fakeDb.favorites.some(
    (fav) => currentUser && fav.userId === currentUser.id && fav.listingId === listing.id
  );
  const html = `
    <div class="detail-container">
      <div class="detail-header" style="background-image: url('${listing.images[0]}')">
        <div class="detail-overlay">
          <h1 class="detail-title">${listing.title}</h1>
          <div class="detail-meta">
            <div><i class="fas fa-map-marker-alt"></i> ${listing.location}</div>
            <div><i class="fas fa-calendar-alt"></i> ${listing.createdAt}</div>
            <div><i class="fas fa-user"></i> Listed by: ${owner ? owner.displayName : 'Unknown'}</div>
          </div>
        </div>
      </div>
      <div class="detail-content">
        <div class="detail-price">$${listing.price}</div>
        <div class="detail-description">${listing.description}</div>
        <div class="detail-actions">
          ${owner ? `<button class="btn-info" id="view-owner-profile-btn">View Lister's Profile</button>` : ''}
          <button class="btn-success ${isLiked ? 'active' : ''}" id="like-listing-btn">
            ${isLiked ? `Liked (${listing.likes})` : `Like (${listing.likes})`}
          </button>
          <button class="btn-success ${isFavorited ? 'active' : ''}" id="favorite-listing-btn">
            ${isFavorited ? 'Remove from Favorites' : 'Add to Favorites'}
          </button>
        </div>
        <div style="margin-top:20px;">
          <button class="btn-primary" id="contact-seller-btn">Contact Seller</button>
        </div>
        <div class="detail-section">
          <h3 class="detail-section-title">Gallery</h3>
          <div class="gallery">
            ${listing.images
              .map(
                (image) => `
              <div class="gallery-item" style="background-image: url('${image}')" data-image="${image}"></div>
            `
              )
              .join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Full Image View -->
    <div class="full-image-view" id="full-image-view">
      <span class="close-icon" id="close-full-image">&times;</span>
      <img src="" alt="Full Image" id="full-image">
    </div>
  `;
  mainContent.innerHTML = html;

  document.getElementById('contact-seller-btn').addEventListener('click', () => {
    openContactModal(listing.userId);
  });

  document.getElementById('like-listing-btn').addEventListener('click', () => handleLikeListing(id));
  document.getElementById('favorite-listing-btn').addEventListener('click', () => handleFavoriteListing(id));

  if (owner) {
    document.getElementById('view-owner-profile-btn').addEventListener('click', () =>
      renderView('profile', owner.id)
    );
  }

  document.querySelectorAll('.gallery-item').forEach((item) => {
    item.addEventListener('click', () => {
      const imageUrl = item.getAttribute('data-image');
      openFullImage(imageUrl);
    });
  });

  document.getElementById('close-full-image').addEventListener('click', () => {
    document.getElementById('full-image-view').style.display = 'none';
  });
}

function addListingCardEventListeners() {
  document.querySelectorAll('.listing-card').forEach((card) => {
    card.addEventListener('click', (e) => {
      // Prevent card click if it was triggered by like or favorite button
      if (e.target.closest('.listing-like') || e.target.closest('.listing-favorite')) return;
      const id = card.getAttribute('data-id');
      renderView('listing-detail', id);
    });
  });

  document.querySelectorAll('.listing-like').forEach((button) => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = button.getAttribute('data-id');
      handleLikeListing(id);
    });
  });

  document.querySelectorAll('.listing-favorite').forEach((button) => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = button.getAttribute('data-id');
      handleFavoriteListing(id);
    });
  });
}

function handleLikeListing(listingId) {
  if (!currentUser) {
    showMessage('Please login to like a listing', 'error');
    return;
  }
  listingId = Number(listingId);
  const listing = [...fakeDb.products, ...fakeDb.services].find((item) => item.id === listingId);
  if (!listing) {
    showMessage('Listing not found', 'error');
    return;
  }
  const likeIndex = fakeDb.userLikes.findIndex(
    (like) => like.userId === currentUser.id && like.listingId === listingId
  );
  if (likeIndex === -1) {
    fakeDb.userLikes.push({ userId: currentUser.id, listingId });
    listing.likes++;
    showMessage('Listing liked!', 'success');
  } else {
    fakeDb.userLikes.splice(likeIndex, 1);
    listing.likes--;
    showMessage('Listing unliked', 'success');
  }
  renderView('listing-detail', listingId);
}

function handleFavoriteListing(listingId) {
  if (!currentUser) {
    showMessage('Please login to favorite a listing', 'error');
    return;
  }
  listingId = Number(listingId);
  const favoriteIndex = fakeDb.favorites.findIndex(
    (fav) => fav.userId === currentUser.id && fav.listingId === listingId
  );
  if (favoriteIndex === -1) {
    fakeDb.favorites.push({ userId: currentUser.id, listingId });
    showMessage('Listing added to favorites!', 'success');
  } else {
    fakeDb.favorites.splice(favoriteIndex, 1);
    showMessage('Listing removed from favorites', 'success');
  }
  renderView('listing-detail', listingId);
}

function openFullImage(imageUrl) {
  fullImage.src = imageUrl;
  document.getElementById('full-image-view').style.display = 'flex';
}
