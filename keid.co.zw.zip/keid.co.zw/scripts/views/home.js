/* Home view */
function renderHome() {
  if (searchInput) {
    searchInput.placeholder = 'Search products or services...';
    searchInput.setAttribute('data-search-type', 'all');
  }
  const productsToShow = fakeDb.products.slice(0, 3);
  const servicesToShow = fakeDb.services.slice(0, 3);

  const html = `
    <!-- Hero Section -->
    <div class="hero">
      <div class="hero-content">
        <h1>Find Local Products & Services</h1>
        <p>Connect with trusted local businesses and service providers in your area.</p>
        <div class="hero-buttons">
          <button class="btn-primary" id="hero-browse-btn">Browse Listings</button>
          ${
            currentUser
              ? `<button class="btn-success" id="hero-add-listing-btn">Add Your Listing</button>`
              : `<button class="btn-success" id="hero-signup-btn">Join Now</button>`
          }
        </div>
      </div>
    </div>

    <!-- Category Section -->
    <div class="category-section">
      <h2 class="section-title">Browse Categories</h2>
      <div class="category-scroll">
        <div class="category-card" id="category-electronics">
          <div style="height:150px; background-image: url('https://picsum.photos/400/300?random=2'); background-size: cover;"></div>
          <h3>Electronics</h3>
          <p>Computers, phones, accessories and more</p>
        </div>
        <div class="category-card" id="category-real-estate">
          <div style="height:150px; background-image: url('https://picsum.photos/400/300?random=3'); background-size: cover;"></div>
          <h3>Real Estate</h3>
          <p>Houses, apartments, and properties</p>
        </div>
        <div class="category-card" id="category-photography">
          <div style="height:150px; background-image: url('https://picsum.photos/400/300?random=4'); background-size: cover;"></div>
          <h3>Photography</h3>
          <p>Professional photography services</p>
        </div>
        <div class="category-card" id="category-vehicles">
          <div style="height:150px; background-image: url('https://picsum.photos/400/300?random=5'); background-size: cover;"></div>
          <h3>Vehicles</h3>
          <p>Cars, bikes, parts and accessories</p>
        </div>
      </div>
    </div>

    <!-- Featured Products -->
    <div class="section">
      <h2 class="section-title">Featured Products</h2>
      <div class="listings-grid">
        ${productsToShow.map((product) => createListingCard(product)).join('')}
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:30px;">
        <button class="btn-primary" id="view-all-products-btn">View All Products</button>
      </div>
    </div>

    <!-- Popular Services -->
    <div class="section">
      <h2 class="section-title">Popular Services</h2>
      <div class="listings-grid">
        ${servicesToShow.map((service) => createListingCard(service)).join('')}
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:30px;">
        <button class="btn-primary" id="view-all-services-btn">View All Services</button>
      </div>
    </div>

    <!-- Call to Action -->
    <div class="section" style="background-color:white; padding:40px; border-radius:12px; margin-top:40px; text-align:center;">
      <h2>Have Something to Offer?</h2>
      <p style="margin-bottom:20px; max-width:600px; margin:auto;">
        List your products or services on Keid and connect with customers in your area.
      </p>
      <button class="btn-success" id="cta-add-listing-btn">${
        currentUser ? 'Add Your Listing' : 'Sign Up to Get Started'
      }</button>
    </div>
  `;
  mainContent.innerHTML = html;

  document.getElementById('hero-browse-btn').addEventListener('click', () => {
    renderCombinedListings();
  });
  if (currentUser) {
    document.getElementById('hero-add-listing-btn').addEventListener('click', () =>
      openModal(addListingModal)
    );
    document.getElementById('cta-add-listing-btn').addEventListener('click', () =>
      openModal(addListingModal)
    );
  } else {
    document.getElementById('hero-signup-btn').addEventListener('click', () =>
      openModal(signupModal)
    );
    document.getElementById('cta-add-listing-btn').addEventListener('click', () =>
      openModal(signupModal)
    );
  }
  document.getElementById('view-all-products-btn').addEventListener('click', () =>
    renderView('products')
  );
  document.getElementById('view-all-services-btn').addEventListener('click', () =>
    renderView('services')
  );
  document.getElementById('category-electronics').addEventListener('click', () =>
    renderView('category', { category: 'electronics' })
  );
  document.getElementById('category-real-estate').addEventListener('click', () =>
    renderView('category', { category: 'real-estate' })
  );
  document.getElementById('category-photography').addEventListener('click', () =>
    renderView('category', { category: 'photography' })
  );
  document.getElementById('category-vehicles').addEventListener('click', () =>
    renderView('category', { category: 'vehicles' })
  );
  addListingCardEventListeners();
}
