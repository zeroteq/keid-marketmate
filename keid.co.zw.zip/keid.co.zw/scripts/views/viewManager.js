/* Central view manager */
function renderView(view, params) {
  currentView = view;
  mainContent.innerHTML = '';
  switch (view) {
    case 'home':
      renderHome();
      break;
    case 'products':
      renderProducts(params);
      break;
    case 'services':
      renderServices(params);
      break;
    case 'category':
      renderCategory(params);
      break;
    case 'search':
      renderSearch(params);
      break;
    case 'listing-detail':
      renderListingDetail(params);
      break;
    case 'profile':
      renderProfile(params);
      break;
    case 'dashboard':
      renderDashboard();
      break;
    case 'favorites':
      renderFavorites();
      break;
    case 'settings':
      renderSettings();
      break;
    case 'about':
      renderAbout();
      break;
    case 'contact':
      renderContact();
      break;
    default:
      renderHome();
  }
}

function renderProducts(params) {
  let products = params && params.listings ? params.listings : [...fakeDb.products];
  let title = 'All Products';
  let subtitle = 'Browse all available products';
  if (params && params.category) {
    title = `${params.category.charAt(0).toUpperCase() + params.category.slice(1)} Products`;
    subtitle = `Browse ${params.category} products`;
    products = products.filter((product) => product.category === params.category);
  }
  if (searchInput) {
    searchInput.placeholder = 'Search products...';
    searchInput.setAttribute('data-search-type', 'products');
  }
  const sortedProducts = sortListings(products, currentSortBy);
  const html = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
      <div>
        <h2 class="section-title">${title}</h2>
        <p class="section-subtitle">${subtitle}</p>
      </div>
      <div>
        <select id="sort-by" style="padding:8px; border-radius:4px;">
          <option value="latest" ${currentSortBy==='latest'?'selected':''}>Sort by: Latest</option>
          <option value="name" ${currentSortBy==='name'?'selected':''}>Sort by: Name</option>
          <option value="price-low-to-high" ${currentSortBy==='price-low-to-high'?'selected':''}>Sort by: Price (Low to High)</option>
          <option value="price-high-to-low" ${currentSortBy==='price-high-to-low'?'selected':''}>Sort by: Price (High to Low)</option>
        </select>
      </div>
    </div>
    <div class="listings-grid">
      ${sortedProducts.map((product) => createListingCard(product)).join('')}
    </div>
  `;
  mainContent.innerHTML = html;
  document.getElementById('sort-by').addEventListener('change', (e) => {
    currentSortBy = e.target.value;
    const sorted = sortListings(products, currentSortBy);
    renderProducts({ listings: sorted });
  });
  addListingCardEventListeners();
}

function renderServices(params) {
  let services = params && params.listings ? params.listings : [...fakeDb.services];
  let title = 'All Services';
  let subtitle = 'Browse all available services';
  if (params && params.category) {
    title = `${params.category.charAt(0).toUpperCase() + params.category.slice(1)} Services`;
    subtitle = `Browse ${params.category} services`;
    services = services.filter((service) => service.category === params.category);
  }
  if (searchInput) {
    searchInput.placeholder = 'Search services...';
    searchInput.setAttribute('data-search-type', 'services');
  }
  const sortedServices = sortListings(services, currentSortBy);
  const html = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
      <div>
        <h2 class="section-title">${title}</h2>
        <p class="section-subtitle">${subtitle}</p>
      </div>
      <div>
        <select id="sort-by" style="padding:8px; border-radius:4px;">
          <option value="latest" ${currentSortBy==='latest'?'selected':''}>Sort by: Latest</option>
          <option value="name" ${currentSortBy==='name'?'selected':''}>Sort by: Name</option>
          <option value="price-low-to-high" ${currentSortBy==='price-low-to-high'?'selected':''}>Sort by: Price (Low to High)</option>
          <option value="price-high-to-low" ${currentSortBy==='price-high-to-low'?'selected':''}>Sort by: Price (High to Low)</option>
        </select>
      </div>
    </div>
    <div class="listings-grid">
      ${sortedServices.map((service) => createListingCard(service)).join('')}
    </div>
  `;
  mainContent.innerHTML = html;
  document.getElementById('sort-by').addEventListener('change', (e) => {
    currentSortBy = e.target.value;
    const sorted = sortListings(services, currentSortBy);
    renderServices({ listings: sorted });
  });
  addListingCardEventListeners();
}

function renderCategory(params) {
  const { category } = params;
  const products = fakeDb.products.filter((product) => product.category === category);
  const services = fakeDb.services.filter((service) => service.category === category);
  const html = `
    <h2 class="section-title">${category.charAt(0).toUpperCase() + category.slice(1)}</h2>
    <p class="section-subtitle">Browse ${category} products and services</p>
    <div class="listings-grid">
      ${products.map((product) => createListingCard(product)).join('')}
      ${services.map((service) => createListingCard(service)).join('')}
    </div>
  `;
  mainContent.innerHTML = html;
  addListingCardEventListeners();
}

function renderSearch(params) {
  const { query, location, listings } = params;
  let results = listings ? listings : [...fakeDb.products, ...fakeDb.services];
  if (query) {
    results = results.filter(
      (item) =>
        (item.title.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query)) &&
        (location ? item.location === location : true)
    );
  }
  renderSearchResults(results, query, location);
}

function renderFavorites() {
  if (!currentUser) {
    mainContent.innerHTML = '<p>Please login to view your favorites</p>';
    return;
  }
  const favoriteListings = [...fakeDb.products, ...fakeDb.services].filter((listing) =>
    fakeDb.favorites.some((fav) => fav.userId === currentUser.id && fav.listingId === listing.id)
  );
  if (favoriteListings.length === 0) {
    mainContent.innerHTML = '<p>You have no favorite listings.</p>';
    return;
  }
  const html = `
    <h2 class="section-title">Favorites</h2>
    <div class="listings-grid">
      ${favoriteListings.map((listing) => createListingCard(listing)).join('')}
    </div>
  `;
  mainContent.innerHTML = html;
  addListingCardEventListeners();
}
