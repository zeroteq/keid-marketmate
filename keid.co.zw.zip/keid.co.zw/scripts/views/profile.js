/* Profile view functions */

function renderProfile(userId) {
  const user = fakeDb.users.find((u) => u.id === Number(userId));
  if (!user) {
    mainContent.innerHTML = '<p>User not found</p>';
    return;
  }
  const userProducts = fakeDb.products.filter((product) => product.userId === user.id);
  const userServices = fakeDb.services.filter((service) => service.userId === user.id);
  const isLiked = fakeDb.userLikes.some(
    (like) => currentUser && like.userId === currentUser.id && like.listingId === userId
  );
  const isOwnProfile = currentUser && currentUser.id === user.id;
  const html = `
    <div class="profile-header">
      <img src="${user.profilePic}" alt="Profile Picture" class="profile-avatar">
      <div class="profile-info">
        <h1 class="profile-name">${user.displayName}</h1>
        <div class="profile-meta">
          <div><i class="fas fa-map-marker-alt"></i> ${user.location}</div>
          <div><i class="fas fa-calendar-alt"></i> Joined ${user.joinedDate}</div>
        </div>
        <div class="profile-stats">
          <div class="profile-stat"><i class="fas fa-thumbs-up"></i> ${user.likes} Likes</div>
          <div class="profile-stat"><i class="fas fa-list"></i> ${
            userProducts.length + userServices.length
          } Listings</div>
        </div>
        <div class="profile-actions">
          <button class="btn-primary" id="contact-user-btn">Contact</button>
          ${
            isOwnProfile
              ? `<button class="btn-info" id="edit-profile-btn">Edit Profile</button>`
              : `<button class="btn-success ${isLiked ? 'active' : ''}" id="like-profile-btn">
                  <i class="fas fa-thumbs-up"></i> ${isLiked ? 'Liked' : 'Like'}
                </button>`
          }
        </div>
      </div>
    </div>
    <div class="tab-container">
      <div class="tabs">
        <div class="tab active" id="tab-listings">Listings</div>
        <div class="tab" id="tab-about">About</div>
      </div>
      <div class="tab-content active" id="tab-content-listings">
        <h2 class="section-title">Listings</h2>
        <div class="listings-grid">
          ${userProducts.map((product) => createListingCard(product)).join('')}
          ${userServices.map((service) => createListingCard(service)).join('')}
        </div>
      </div>
      <div class="tab-content" id="tab-content-about">
        <h2 class="section-title">About</h2>
        <p>${user.bio || 'No bio available'}</p>
      </div>
    </div>
  `;
  mainContent.innerHTML = html;

  document.getElementById('contact-user-btn').addEventListener('click', () => openContactModal(user.id));
  if (isOwnProfile) {
    document.getElementById('edit-profile-btn').addEventListener('click', () => openEditProfileModal(user));
  } else {
    document.getElementById('like-profile-btn').addEventListener('click', () => handleLikeProfile(user.id));
  }

  document.getElementById('tab-listings').addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((tab) => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach((content) => content.classList.remove('active'));
    document.getElementById('tab-listings').classList.add('active');
    document.getElementById('tab-content-listings').classList.add('active');
  });

  document.getElementById('tab-about').addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((tab) => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach((content) => content.classList.remove('active'));
    document.getElementById('tab-about').classList.add('active');
    document.getElementById('tab-content-about').classList.add('active');
  });

  addListingCardEventListeners();
}

function handleLikeProfile(userId) {
  if (!currentUser) {
    showMessage('Please login to like a profile', 'error');
    return;
  }
  userId = Number(userId);
  const user = fakeDb.users.find((u) => u.id === userId);
  if (!user) {
    showMessage('User not found', 'error');
    return;
  }
  const likeIndex = fakeDb.userLikes.findIndex(
    (like) => like.userId === currentUser.id && like.listingId === userId
  );
  if (likeIndex === -1) {
    fakeDb.userLikes.push({ userId: currentUser.id, listingId: userId });
    user.likes++;
    showMessage('Profile liked!', 'success');
  } else {
    fakeDb.userLikes.splice(likeIndex, 1);
    user.likes--;
    showMessage('Profile unliked', 'success');
  }
  renderProfile(userId);
}
