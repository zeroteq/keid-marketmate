/* Contact view functions */
function renderContact() {
  const html = `
    <h2 class="section-title">Contact Us</h2>
    <p>If you have any questions or need assistance, please feel free to reach out.</p>
    <div class="form-container">
      <form id="contact-us-form">
        <div class="form-group">
          <label for="contact-us-name">Name</label>
          <input type="text" id="contact-us-name" required>
        </div>
        <div class="form-group">
          <label for="contact-us-email">Email</label>
          <input type="email" id="contact-us-email" required>
        </div>
        <div class="form-group">
          <label for="contact-us-subject">Subject</label>
          <input type="text" id="contact-us-subject" required>
        </div>
        <div class="form-group">
          <label for="contact-us-message">Message</label>
          <textarea id="contact-us-message" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn-primary">Send Message</button>
      </form>
    </div>
  `;
  mainContent.innerHTML = html;
  document.getElementById('contact-us-form').addEventListener('submit', handleContactUsForm);
}

function handleContactUsForm(e) {
  e.preventDefault();
  const name = document.getElementById('contact-us-name').value;
  const email = document.getElementById('contact-us-email').value;
  const subject = document.getElementById('contact-us-subject').value;
  const message = document.getElementById('contact-us-message').value;
  const mailtoLink = `mailto:your-email@example.com?subject=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage: ${message}`)}`;
  window.location.href = mailtoLink;
}
