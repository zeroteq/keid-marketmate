/* About view */
function renderAbout() {
  const html = `
    <h2 class="section-title">About Us</h2>
    <p>Keid is a platform that connects local businesses with customers in their area. Our mission is to make it easy for people to find and support local products and services.</p>
    <p>Whether you're looking for a new product or need a service, Keid has you covered. Join our community today and start exploring!</p>
  `;
  mainContent.innerHTML = html;
}
