/* Utility functions */

function openModal(modal) {
  modal.style.display = 'flex';
}

function closeModal(modal) {
  modal.style.display = 'none';
}

function showMessage(message, type) {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

function sortListings(listings, sortBy) {
  let sortedListings = [...listings];
  switch (sortBy) {
    case 'latest':
      sortedListings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      break;
    case 'name':
      sortedListings.sort((a, b) => a.title.localeCompare(b.title));
      break;
    case 'price-low-to-high':
      sortedListings.sort((a, b) => a.price - b.price);
      break;
    case 'price-high-to-low':
      sortedListings.sort((a, b) => b.price - a.price);
      break;
    default:
      break;
  }
  return sortedListings;
}

function renderImagePreviews() {
  if (!imagePreview) return;
  imagePreview.innerHTML = '';
  uploadedImages.forEach((image, index) => {
    const div = document.createElement('div');
    div.className = 'image-preview-item';
    div.innerHTML = `
      <img src="${image}" alt="Preview ${index + 1}" style="width:80px;height:80px;object-fit:cover;border-radius:4px;">
      <span class="remove" data-index="${index}">&times;</span>
    `;
    imagePreview.appendChild(div);
  });
  document.querySelectorAll('.image-preview-item .remove').forEach((button) => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const index = button.getAttribute('data-index');
      uploadedImages.splice(index, 1);
      renderImagePreviews();
    });
  });
}

function renderEditListingImagePreviews(listing) {
  if (!editImagePreview) return;
  editImagePreview.innerHTML = '';
  if (listing.images && listing.images.length > 0) {
    listing.images.forEach((image, index) => {
      const div = document.createElement('div');
      div.className = 'image-preview-item';
      div.innerHTML = `
        <img src="${image}" alt="Preview ${index + 1}" style="width:80px;height:80px;object-fit:cover;border-radius:4px;">
        <span class="remove" data-index="${index}">&times;</span>
      `;
      editImagePreview.appendChild(div);
    });
    document.querySelectorAll('#edit-image-preview .remove').forEach((button) => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const index = button.getAttribute('data-index');
        listing.images.splice(index, 1);
        renderEditListingImagePreviews(listing);
      });
    });
  }
}
