// Authentication functions

loginForm.addEventListener('submit', handleLogin);
signupForm.addEventListener('submit', handleSignup);
logoutLink.addEventListener('click', handleLogout);

function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const user = fakeDb.users.find((u) => u.email === email && u.password === password);
  if (user) {
    currentUser = user;
    updateAuthUI();
    closeModal(loginModal);
    renderView('home');
    showMessage('Successfully logged in!', 'success');
  } else {
    showMessage('Invalid email or password', 'error');
  }
}

function handleSignup(e) {
  e.preventDefault();
  const name = document.getElementById('signup-name').value;
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const confirmPassword = document.getElementById('signup-confirm-password').value;

  if (password !== confirmPassword) {
    showMessage('Passwords do not match', 'error');
    return;
  }

  if (fakeDb.users.some((u) => u.email === email)) {
    showMessage('Email already in use', 'error');
    return;
  }

  const newUser = {
    id: fakeDb.users.length + 1,
    name: name,
    displayName: name,
    email: email,
    password: password,
    profilePic: 'https://picsum.photos/400/400?random=15',
    phone: '+263',
    whatsapp: '+263',
    bio: '',
    joinedDate: new Date().toISOString().split('T')[0],
    location: '',
    likes: 0
  };

  fakeDb.users.push(newUser);
  currentUser = newUser;
  updateAuthUI();
  closeModal(signupModal);
  renderView('settings');
  showMessage('Account created successfully!', 'success');
}

function handleLogout() {
  currentUser = null;
  updateAuthUI();
  renderView('home');
  showMessage('Logged out successfully', 'success');
}

function updateAuthUI() {
  if (currentUser) {
    if (userActions) userActions.style.display = 'none';
    if (userProfile) userProfile.style.display = 'flex';
    navUsername.textContent = currentUser.displayName;
    navProfileImg.src = currentUser.profilePic;
  } else {
    if (userActions) userActions.style.display = 'flex';
    if (userProfile) userProfile.style.display = 'none';
  }
}
