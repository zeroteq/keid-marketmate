// Fake database and session data
const fakeDb = {
  users: [
    {
      id: 1,
      name: 'Test Account',
      displayName: 'Test Account',
      email: 'test@gmail.com',
      password: '12345678',
      profilePic: 'https://picsum.photos/400/400?random=11',
      phone: '+263551234567',
      whatsapp: '+263551234567',
      bio: 'Professional test account with 10 years of experience. Specializing in bugs and more bugs.',
      joinedDate: '2024-01-15',
      location: 'Plumtree',
      likes: 45
    },
    {
      id: 2,
      name: 'Scammer Knox',
      displayName: 'Scammer Knox',
      email: 'scam@knox.com',
      password: 'password',
      profilePic: 'https://picsum.photos/400/400?random=11',
      phone: '+263557654321',
      whatsapp: '+263557654321',
      bio: 'Professional scammer with 10 years of experience. Specializing in OnlyScams',
      joinedDate: '2024-02-10',
      location: 'Bulawayo',
      likes: 78
    }
  ],
  products: [
    {
      id: 10,
      type: 'product',
      title: 'Professional DSLR Camera',
      price: 1200,
      description: 'Near-new condition professional DSLR camera with 24.2MP sensor, 4K video recording, and touchscreen. Includes 2 lenses, camera bag, and extra battery.',
      location: 'Bulawayo',
      images: [
        'https://picsum.photos/800/600?random=12',
        'https://picsum.photos/800/600?random=13',
        'https://picsum.photos/800/600?random=14',
        'https://picsum.photos/800/600?random=15'
      ],
      userId: 1,
      likes: 12,
      createdAt: '2025-01-10',
      category: 'electronics'
    },
    {
      id: 11,
      type: 'product',
      title: 'Refurbished Laptop',
      price: 599,
      description: 'Refurbished 14" laptop with Intel i5 processor, 16GB RAM, 512GB SSD, and backlit keyboard. Perfect condition with fresh install of Windows 11.',
      location: 'Bulawayo',
      images: [
        'https://picsum.photos/800/600?random=13',
        'https://picsum.photos/800/600?random=14'
      ],
      userId: 2,
      likes: 5,
      createdAt: '2025-01-20',
      category: 'electronics'
    }
  ],
  services: [
    {
      id: 20,
      type: 'service',
      title: 'Professional Photography',
      price: 120,
      description: 'Professional portrait and event photography services. Includes full editing and delivery of high-resolution digital files. Available for bookings throughout the city.',
      location: 'Plumtree',
      images: [
        'https://picsum.photos/800/600?random=16',
        'https://picsum.photos/800/600?random=14',
        'https://picsum.photos/800/600?random=17'
      ],
      userId: 1,
      likes: 31,
      createdAt: '2025-01-12',
      category: 'photography'
    },
    {
      id: 21,
      type: 'service',
      title: 'Computer Repair & Setup',
      price: 75,
      description: 'On-site computer repair, setup, and troubleshooting services for PC and Mac. Virus removal, hardware upgrades, OS installation, and more.',
      location: 'Bulawayo',
      images: [
        'https://picsum.photos/800/600?random=18',
        'https://picsum.photos/800/600?random=19'
      ],
      userId: 2,
      likes: 19,
      createdAt: '2025-01-23',
      category: 'electronics'
    },
    {
      id: 22,
      type: 'service',
      title: 'Nkust House for Rent',
      price: 75,
      description: '20 Roomed House with windows and doors, Security not guaranteed but you will be safe, Neighbourhood WiFi is guaranteed.',
      location: 'Bulawayo',
      images: [
        'https://picsum.photos/800/600?random=20',
        'https://picsum.photos/800/600?random=14',
        'https://picsum.photos/800/600?random=10'
      ],
      userId: 2,
      likes: 29,
      createdAt: '2025-01-23',
      category: 'real-estate'
    }
  ],
  favorites: [],
  userLikes: []
};

let currentUser = null;
let currentView = 'home';
let uploadedImages = [];
let currentSortBy = 'latest';
