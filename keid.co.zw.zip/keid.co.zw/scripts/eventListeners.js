/* Attach event listeners after DOM loads */
document.addEventListener('DOMContentLoaded', () => {
  // Open login and signup modals
  loginButton.addEventListener('click', () => openModal(loginModal));
  signupButton.addEventListener('click', () => openModal(signupModal));

  // Switch between login and signup modals
  switchToSignup.addEventListener('click', () => {
    closeModal(loginModal);
    openModal(signupModal);
  });
  switchToLogin.addEventListener('click', () => {
    closeModal(signupModal);
    openModal(loginModal);
  });

  // Close modal when clicking on any close icon
  closeButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const modal = button.closest('.modal');
      closeModal(modal);
    });
  });

  // Close modal when clicking outside the modal content
  window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
      closeModal(e.target);
    }
  });
});
