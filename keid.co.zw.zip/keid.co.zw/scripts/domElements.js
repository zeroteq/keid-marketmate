// Grab commonly used DOM elements
const mainContent = document.getElementById('main-content');
const userActions = document.querySelector('.auth-links');
const userProfile = document.getElementById('user-profile');
const navUsername = document.getElementById('nav-username');
const navProfileImg = document.getElementById('nav-profile-img');
const loginButton = document.getElementById('login-button');
const signupButton = document.getElementById('signup-button');
const homeLink = document.getElementById('home-link');
const productsLink = document.getElementById('products-link');
const servicesLink = document.getElementById('services-link');
const aboutLink = document.getElementById('about-link');
const contactLink = document.getElementById('contact-link');
const navProfileLink = document.getElementById('nav-profile-link');
const navDashboardLink = document.getElementById('nav-dashboard-link');
const navFavoritesLink = document.getElementById('nav-favorites-link');
const navSettingsLink = document.getElementById('nav-settings-link');
const logoutLink = document.getElementById('logout-link');

// Modals
const loginModal = document.getElementById('login-modal');
const signupModal = document.getElementById('signup-modal');
const addListingModal = document.getElementById('add-listing-modal');
const contactModal = document.getElementById('contact-modal');
const editProfileModal = document.getElementById('edit-profile-modal');
const editListingModal = document.getElementById('edit-listing-modal');

// Modal close buttons and switches
const closeButtons = document.querySelectorAll('.modal-close');
const switchToSignup = document.getElementById('switch-to-signup');
const switchToLogin = document.getElementById('switch-to-login');

// Forms
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const addListingForm = document.getElementById('add-listing-form');
const editProfileForm = document.getElementById('edit-profile-form');
const editListingForm = document.getElementById('edit-listing-form');

// (Optional) Search elements – if they exist in your markup
const searchInput = document.getElementById('search-input') || document.createElement('input');
const locationSelect = document.getElementById('location-select') || document.createElement('select');
const searchButton = document.getElementById('search-button') || document.createElement('button');

// Image upload elements
const imageUpload = document.getElementById('image-upload');
const imageInput = document.getElementById('image-input');
const imagePreview = document.getElementById('image-preview');

// Edit profile image upload elements
const editProfilePicPreview = document.getElementById('edit-profile-pic-preview');
const editProfilePicInput = document.getElementById('edit-profile-pic-input');
const editImageUpload = document.getElementById('edit-image-upload');
const editImageInput = document.getElementById('edit-image-input');
const editImagePreview = document.getElementById('edit-image-preview');

// Full image view elements
const fullImageView = document.getElementById('full-image-view');
const fullImage = document.getElementById('full-image');
const closeFullImageBtn = document.getElementById('close-full-image');
