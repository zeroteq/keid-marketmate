# Keid: Because Kmart Was Too Mainstream 🛒

A revolutionary marketplace platform built by three coding legends who definitely didn't procrastinate until 3 AM.  

Brendon, Nyasha, and Knowledge - The Holy Trinity of "It Works on My Machine"

👥 Contributing

Please don't.** But if you insist:  

1. I fucked soke functions 
2. Add more  
3. Submit PR → Wait for Brendon to say "LGTM" while Nyasha facepalms  

---

## 📜 License

WTFPL (Want-To-Fix-This-Please License)  
Do whatever, we stopped caring 3 commits in.

---

## 🙏 Acknowledgements

- Brendon - The gay nigga  
- Nyasha - The smart nigga but he can be stupid
- Knowledge - console.log()` remover  
- AI - Our real senior developer       And The only reason this exists  

---

Keid: Making Zim Marketplace Look Competent Since 2025 💫 

---

## 🚀 Project Description

Keid is the world's most innovative local marketplace platform, featuring:  
✅ Fake database technology (guaranteed to crash)  
✅ 2003-era modal windows  
✅ A login system that stores passwords in plain text (cybersecurity who?)  
✅ Random Lorem Picsum images (because actual product photos are overrated)  

Revolutionizing how people in Bulawayo list DSLR cameras they don't own!"- No One, Ever

---

✨ Key Features

- Groundbreaking Search 
  Find exactly what you're *not* looking for with our location-filter-that-sometimes-works!

- Epic User Profiles  
  Showcase your best 400x400 pixel potato-quality avatar!

- Listing Magic  
  Post items with prices in USD while living in Zimbabwe - what could go wrong?

- Security First
  Our "encryption" is watching hackers facepalm at our `password === password` validation.
